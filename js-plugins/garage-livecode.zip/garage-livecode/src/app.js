// TODO: Build an awesome garage!

// récupérer les données du user du form

// récupérer les inputs
const brandInput = document.getElementById("brand");
const modelInput = document.getElementById("model");
const plateInput = document.getElementById("plate");
const ownerInput = document.getElementById("owner");

const submitButton = document.querySelector(".btn");

const carLists = document.querySelector(".cars-list");

const fetchCars = (options) => {
  fetch("https://wagon-garage-api.herokuapp.com/jeanro/cars", options)
    .then((response) => response.json())
    .then((data) => {
      data.forEach((element) => {
        const owner = element.owner;
        const model = element.model;
        const plate = element.plate;
        const brand = element.brand;

        const card = `<div class="car">
        <div class="car-image">
          <img src="http://loremflickr.com/280/280/${model}" />
        </div>
        <div class="car-info">
          <h4>${brand} ${model}</h4>
          <p><strong>Owner:</strong>${owner}</p>
          <p><strong>Plate:</strong> ${plate}</p>
        </div>
      </div>`;

        carLists.insertAdjacentHTML("beforeend", card);
      });
    });
};
fetchCars();

// écouter le click sur le bouton
submitButton.addEventListener("click", (event) => {
  event.preventDefault();
  console.log(brandInput.value);
  console.log(modelInput.value);
  console.log(plateInput.value);
  console.log(ownerInput.value);
  // transformer en hash
  const car = {
    "brand": brandInput.value,
    "model": modelInput.value,
    "owner": ownerInput.value,
    "plate": plateInput.value,
  };
  fetch(`https://wagon-garage-api.herokuapp.com/jeanro/cars`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(car),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
    });
});

// const createCar = () => {
//   const
// }
