You can clone this repo and then run:

```bash
yarn install
webpack-dev-server
```
