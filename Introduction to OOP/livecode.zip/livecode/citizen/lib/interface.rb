require_relative "citizen.rb"

jean = Citizen.new("jean", "krupa", 39)

p jean.first_name